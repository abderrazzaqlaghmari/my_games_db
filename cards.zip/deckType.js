const STANDARD = 0;
const EUCHRE = 1;
const PINOCHLE = 2;
